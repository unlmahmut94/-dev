<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BasvuruController extends Controller
{
    public function anasayfa()
    {
        return view('anasayfa');
    }

    public function form()
    {
        return view('basvuru');
    }

    public function kaydet(Request $request)
    {
        // Formdan gelen veriler Request ile alınıyor
        $veriler = $request->all();
        // Sonuç sayfasına aktarılıyor
        return view('sonuc', compact('veriler'));
    }

    public function hakkimizda()
    {
        return view('anasayfa'); 
    }
}