<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BasvuruController;

// En az 4 route isteniyor ve en az 2'sine isim (name) verilecek
Route::get('/', [BasvuruController::class, 'anasayfa'])->name('anasayfa');
Route::get('/basvuru', [BasvuruController::class, 'form'])->name('basvuru.form');
Route::post('/basvuru-gonder', [BasvuruController::class, 'kaydet'])->name('basvuru.kaydet');
Route::get('/hakkimizda', [BasvuruController::class, 'hakkimizda'])->name('hakkimizda');