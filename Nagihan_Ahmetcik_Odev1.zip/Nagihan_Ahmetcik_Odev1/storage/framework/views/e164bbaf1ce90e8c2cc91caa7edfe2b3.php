<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Başvuru Sonucu</title>
</head>
<body>
    <h1>Başvurunuz Başarıyla Alındı!</h1>
    <p>Aşağıdaki bilgilerle başvuru yaptınız:</p>

    <ul>
        <li><strong>Ad Soyad:</strong> <?php echo e($veriler['ad_soyad']); ?></li>
        <li><strong>Öğrenci Numarası:</strong> <?php echo e($veriler['ogrenci_no']); ?></li>
        <li><strong>Bölüm:</strong> <?php echo e($veriler['bolum']); ?></li>
        <li><strong>E-posta:</strong> <?php echo e($veriler['eposta']); ?></li>
        <li><strong>Seçilen Etkinlik:</strong> <?php echo e($veriler['etkinlik']); ?></li>
        <li><strong>Başvuru Nedeni:</strong> <?php echo e($veriler['neden']); ?></li>
    </ul>

    <br>
    <a href="<?php echo e(route('anasayfa')); ?>">Ana Sayfaya Dön</a>
</body>
</html><?php /**PATH C:\laragon\www\etkinlik-basvuru\resources\views/sonuc.blade.php ENDPATH**/ ?>