<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Başvuru Formu</title>
</head>
<body>
    <h1>Etkinlik Başvuru Formu</h1>
    
    <!-- POST metodu ile gönderilecek -->
    <form action="<?php echo e(route('basvuru.kaydet')); ?>" method="POST">
        <!-- Güvenlik için <?php echo csrf_field(); ?> kullanılıyor -->
        <?php echo csrf_field(); ?>
        
        <label>Ad Soyad:</label><br>
        <input type="text" name="ad_soyad" required><br><br>

        <label>Öğrenci Numarası:</label><br>
        <input type="text" name="ogrenci_no" required><br><br>

        <label>Bölüm:</label><br>
        <input type="text" name="bolum" required><br><br>

        <label>E-posta:</label><br>
        <input type="email" name="eposta" required><br><br>

        <label>Etkinlik Seçimi:</label><br>
        <select name="etkinlik" required>
            <option value="Yapay Zeka Zirvesi">Yapay Zeka Zirvesi</option>
            <option value="İnşaat Mühendisliği Konferansı">İnşaat Mühendisliği Konferansı</option>
            <option value="Girişimcilik Paneli">Girişimcilik Paneli</option>
        </select><br><br>

        <label>Başvuru Nedeni:</label><br>
        <textarea name="neden" rows="4" required></textarea><br><br>

        <button type="submit">Başvuruyu Gönder</button>
    </form>
</body>
</html><?php /**PATH C:\laragon\www\etkinlik-basvuru\resources\views/basvuru.blade.php ENDPATH**/ ?>