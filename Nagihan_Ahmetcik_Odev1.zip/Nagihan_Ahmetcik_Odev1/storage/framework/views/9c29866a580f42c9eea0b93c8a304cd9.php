<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Etkinlik Başvuru Sistemi</title>
</head>
<body>
    <h1>Etkinlik Başvuru Sistemine Hoş Geldiniz</h1>
    <!-- route('name') yapısı kullanılarak link veriliyor -->
    <a href="<?php echo e(route('basvuru.form')); ?>">Başvuru Yapmak İçin Tıklayın</a>
</body>
</html><?php /**PATH C:\laragon\www\etkinlik-basvuru\resources\views/anasayfa.blade.php ENDPATH**/ ?>