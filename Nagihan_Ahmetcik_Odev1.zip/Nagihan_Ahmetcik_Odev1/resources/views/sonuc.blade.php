<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Başvuru Sonucu</title>
</head>
<body>
    <h1>Başvurunuz Başarıyla Alındı!</h1>
    <p>Aşağıdaki bilgilerle başvuru yaptınız:</p>

    <ul>
        <li><strong>Ad Soyad:</strong> {{ $veriler['ad_soyad'] }}</li>
        <li><strong>Öğrenci Numarası:</strong> {{ $veriler['ogrenci_no'] }}</li>
        <li><strong>Bölüm:</strong> {{ $veriler['bolum'] }}</li>
        <li><strong>E-posta:</strong> {{ $veriler['eposta'] }}</li>
        <li><strong>Seçilen Etkinlik:</strong> {{ $veriler['etkinlik'] }}</li>
        <li><strong>Başvuru Nedeni:</strong> {{ $veriler['neden'] }}</li>
    </ul>

    <br>
    <a href="{{ route('anasayfa') }}">Ana Sayfaya Dön</a>
</body>
</html>